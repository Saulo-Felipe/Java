package JogoDaVelha2;

public class Main {
  public static ShowOnScreen showOnScreen = new ShowOnScreen();

  public static void main(String[] args) {

    showOnScreen.homeMenu(); // Show menu

  }


}
